/* global React, ReactDOM, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakColor, TweakButton */
const { useState, useEffect, useRef, useMemo } = React;

/* ---------- defaults ---------- */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "felt",
  "density": "comfortable",
  "showTurnDots": true,
  "showDelta": "chip"
}/*EDITMODE-END*/;

/* ---------- themes ---------- */
const THEMES = {
  felt: {
    name: "Felt",
    bg: "#0e2b22",
    bg2: "#0a1f19",
    panel: "#f6efe1",
    panelMute: "#ece2cc",
    ink: "#1a1410",
    inkMute: "#5a4f42",
    rule: "#d8cdb4",
    accent: "#b8242b",   // suit red
    accent2: "#c79a3e",  // gold
    teamA: "#b8242b",
    teamB: "#1f4d8a",
    teamC: "#3e7a3a",
    chipBg: "#fff",
    chipInk: "#1a1410",
  },
  parchment: {
    name: "Parchment",
    bg: "#efe7d2",
    bg2: "#e6dcc1",
    panel: "#fbf6e9",
    panelMute: "#f1ead4",
    ink: "#2b1a0e",
    inkMute: "#7a6750",
    rule: "#cdbf9b",
    accent: "#9e1b22",
    accent2: "#a67524",
    teamA: "#9e1b22",
    teamB: "#214a6f",
    teamC: "#3e6a36",
    chipBg: "#fff",
    chipInk: "#2b1a0e",
  },
  midnight: {
    name: "Midnight",
    bg: "#0b0f1a",
    bg2: "#070a12",
    panel: "#141a2a",
    panelMute: "#1c2336",
    ink: "#f1ecd9",
    inkMute: "#8a8fa3",
    rule: "#2a3148",
    accent: "#e2545a",
    accent2: "#e7c46a",
    teamA: "#e2545a",
    teamB: "#6aa6ff",
    teamC: "#7cd49a",
    chipBg: "#0b0f1a",
    chipInk: "#f1ecd9",
  },
};

/* ---------- helpers ---------- */
const initials = (name) =>
  (name || "").split(",").map(s => s.trim()).filter(Boolean)
    .map(s => s[0].toUpperCase()).join("") || "—";

const num = (v) => parseInt(v) || 0;

/* persist + restore using localStorage so prototype feels real */
function useLocal(key, initial) {
  const [v, setV] = useState(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw !== null ? JSON.parse(raw) : initial;
    } catch { return initial; }
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(v)); } catch {}
  }, [key, v]);
  return [v, setV];
}

/* ---------- main ---------- */
function BelotApp() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const theme = THEMES[t.theme] || THEMES.felt;

  /* game state */
  const [rows, setRows] = useLocal("bc.rows", []);
  const [headers, setHeaders] = useLocal("bc.headers", { a: "Us", b: "Them", c: "Third" });
  const [showThird, setShowThird] = useLocal("bc.showThird", false);
  const [history, setHistory] = useLocal("bc.history", []);

  /* draft inputs */
  const [draft, setDraft] = useState({ a: "", b: "", c: "" });

  /* modals */
  const [modal, setModal] = useState(null); // 'settings' | 'history' | null
  const [editingHeader, setEditingHeader] = useState(null);
  const [confirm, setConfirm] = useState(null);

  /* totals = last row */
  const totals = useMemo(() => {
    if (!rows.length) return { a: 0, b: 0, c: 0 };
    const last = rows[rows.length - 1];
    return { a: last.a, b: last.b, c: last.c || 0 };
  }, [rows]);

  /* belot to 151 — show progress */
  const TARGET = 151;
  const leader = useMemo(() => {
    const arr = [
      { key: "a", v: totals.a, label: headers.a, color: theme.teamA },
      { key: "b", v: totals.b, label: headers.b, color: theme.teamB },
      ...(showThird ? [{ key: "c", v: totals.c, label: headers.c, color: theme.teamC }] : []),
    ];
    arr.sort((x, y) => y.v - x.v);
    return arr;
  }, [totals, headers, showThird, theme]);

  /* turn indicator */
  const nextTurn = () => {
    const lists = [headers.a, headers.b, ...(showThird ? [headers.c] : [])]
      .map(h => h.split(",").map(s => s.trim()).filter(Boolean));
    const all = [];
    const max = Math.max(...lists.map(l => l.length || 1));
    for (let i = 0; i < max; i++) lists.forEach(l => l[i] && all.push(l[i]));
    if (!all.length) return "—";
    return all[rows.length % all.length][0].toUpperCase();
  };

  const canAdd = draft.a !== "" || draft.b !== "" || (showThird && draft.c !== "");

  const addRow = () => {
    if (!canAdd) return;
    const dA = num(draft.a), dB = num(draft.b), dC = num(draft.c);
    const newRow = {
      id: rows.length + 1,
      a: totals.a + dA,
      b: totals.b + dB,
      c: totals.c + dC,
      dA, dB, dC,
      turn: nextTurn(),
      ts: Date.now(),
    };
    setRows([...rows, newRow]);
    setDraft({ a: "", b: "", c: "" });
  };

  const deleteLast = () => {
    if (!rows.length) return;
    setRows(rows.slice(0, -1));
  };

  const saveAndReset = () => {
    if (rows.length) {
      setHistory([
        ...history,
        {
          id: Date.now(),
          date: new Date().toISOString(),
          rows,
          headers: { ...headers },
          showThird,
          totals,
        },
      ]);
    }
    setRows([]);
    setDraft({ a: "", b: "", c: "" });
  };

  const resetEverything = () => {
    setRows([]); setHistory([]);
    setHeaders({ a: "Us", b: "Them", c: "Third" });
    setShowThird(false);
    setDraft({ a: "", b: "", c: "" });
    try { localStorage.clear(); } catch {}
    setConfirm(null);
  };

  /* css vars */
  const cssVars = {
    "--bg": theme.bg, "--bg2": theme.bg2,
    "--panel": theme.panel, "--panel-mute": theme.panelMute,
    "--ink": theme.ink, "--ink-mute": theme.inkMute,
    "--rule": theme.rule,
    "--accent": theme.accent, "--accent2": theme.accent2,
    "--team-a": theme.teamA, "--team-b": theme.teamB, "--team-c": theme.teamC,
    "--chip-bg": theme.chipBg, "--chip-ink": theme.chipInk,
    "--row-pad": t.density === "compact" ? "8px 12px" : t.density === "roomy" ? "16px 14px" : "12px 14px",
  };

  return (
    <div className="bc-root" style={cssVars} data-screen-label="01 Calculator">
      <div className="bc-bg" />
      <div className="bc-frame">
        <Header
          theme={theme}
          headers={headers}
          showThird={showThird}
          totals={totals}
          rowCount={rows.length}
          onSettings={() => setModal("settings")}
          onHistory={() => setModal("history")}
          target={TARGET}
          leader={leader}
          showTurnDots={t.showTurnDots}
          nextTurnLetter={nextTurn()}
        />

        <ScoreTable
          rows={rows}
          headers={headers}
          showThird={showThird}
          showDelta={t.showDelta}
          onDeleteLast={deleteLast}
          theme={theme}
        />

        <InputBar
          draft={draft}
          setDraft={setDraft}
          headers={headers}
          showThird={showThird}
          canAdd={canAdd}
          onAdd={addRow}
          canSave={rows.length > 0}
          onSave={() => setConfirm({ kind: "save" })}
        />
      </div>

      {modal === "settings" && (
        <Modal title="Settings" onClose={() => setModal(null)}>
          <SettingsBody
            headers={headers}
            setHeaders={setHeaders}
            showThird={showThird}
            setShowThird={setShowThird}
            onResetAll={() => setConfirm({ kind: "reset" })}
            t={t}
            setTweak={setTweak}
          />
        </Modal>
      )}

      {modal === "history" && (
        <Modal title="Game history" onClose={() => setModal(null)}>
          <HistoryBody history={history} onClear={() => setHistory([])} />
        </Modal>
      )}

      {confirm && (
        <ConfirmDialog
          title={confirm.kind === "reset" ? "Reset everything?" : "Save game and start new?"}
          body={
            confirm.kind === "reset"
              ? "This clears the current game, history, names and settings. Cannot be undone."
              : `Archive this game (${rows.length} rounds) to history and clear the board.`
          }
          confirmLabel={confirm.kind === "reset" ? "Reset" : "Save & new game"}
          danger={confirm.kind === "reset"}
          onConfirm={() => {
            if (confirm.kind === "reset") resetEverything();
            else { saveAndReset(); setConfirm(null); }
          }}
          onCancel={() => setConfirm(null)}
        />
      )}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme">
          <TweakRadio
            label="Palette"
            value={t.theme}
            onChange={(v) => setTweak("theme", v)}
            options={[
              { value: "felt", label: "Felt" },
              { value: "parchment", label: "Parch." },
              { value: "midnight", label: "Night" },
            ]}
          />
        </TweakSection>
        <TweakSection label="Layout">
          <TweakRadio
            label="Density"
            value={t.density}
            onChange={(v) => setTweak("density", v)}
            options={[
              { value: "compact", label: "Compact" },
              { value: "comfortable", label: "Comfy" },
              { value: "roomy", label: "Roomy" },
            ]}
          />
          <TweakRadio
            label="Round delta"
            value={t.showDelta}
            onChange={(v) => setTweak("showDelta", v)}
            options={[
              { value: "chip", label: "Chip" },
              { value: "inline", label: "Inline" },
              { value: "off", label: "Off" },
            ]}
          />
        </TweakSection>
        <TweakSection label="Behavior">
          <TweakToggle
            label="Next-dealer hint"
            value={t.showTurnDots}
            onChange={(v) => setTweak("showTurnDots", v)}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

/* ---------- header ---------- */
function Header({ headers, showThird, totals, onSettings, onHistory, target, leader, theme, showTurnDots, nextTurnLetter, rowCount }) {
  const teams = [
    { key: "a", label: headers.a, v: totals.a, color: theme.teamA },
    { key: "b", label: headers.b, v: totals.b, color: theme.teamB },
    ...(showThird ? [{ key: "c", label: headers.c, v: totals.c, color: theme.teamC }] : []),
  ];
  const top = leader[0];
  const second = leader[1];
  const gap = top && second ? top.v - second.v : 0;

  return (
    <header className="bc-header">
      <div className="bc-brand">
        <BelotMark theme={theme} />
        <div className="bc-brand-text">
          <div className="bc-brand-eyebrow">Belot</div>
          <div className="bc-brand-title">Score Pad</div>
        </div>
        <div className="bc-actions">
          <IconBtn label="History" onClick={onHistory}><IconHistory /></IconBtn>
          <IconBtn label="Settings" onClick={onSettings}><IconCog /></IconBtn>
        </div>
      </div>

      <div className={`bc-totals bc-totals-${teams.length}`}>
        {teams.map(team => {
          const pct = Math.min(100, Math.round((team.v / target) * 100));
          const isLeader = top && team.key === top.key && team.v > 0;
          return (
            <div key={team.key} className="bc-team-card" style={{ "--team": team.color }}>
              <div className="bc-team-row">
                <span className="bc-team-name" title={team.label}>{team.label}</span>
                {isLeader && <span className="bc-team-badge">Lead</span>}
              </div>
              <div className="bc-team-score">
                <span className="bc-team-num">{team.v}</span>
                <span className="bc-team-target">/ {target}</span>
              </div>
              <div className="bc-team-bar"><span style={{ width: `${pct}%` }} /></div>
            </div>
          );
        })}
      </div>

      {showTurnDots && (
        <div className="bc-turn-strip">
          <span className="bc-turn-label">Next deal</span>
          <span className="bc-turn-dot">{nextTurnLetter}</span>
          <span className="bc-turn-meta">Round {rowCount + 1}{gap > 0 && top ? ` · ${top.label} +${gap}` : ""}</span>
        </div>
      )}
    </header>
  );
}

/* ---------- score table ---------- */
function ScoreTable({ rows, headers, showThird, showDelta, onDeleteLast, theme }) {
  const cols = showThird ? 3 : 2;
  const ref = useRef(null);
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [rows.length]);

  if (!rows.length) {
    return (
      <div className="bc-table-wrap bc-empty-wrap">
        <div className="bc-empty">
          <BelotMark theme={theme} large />
          <div className="bc-empty-title">New hand, fresh slate.</div>
          <div className="bc-empty-sub">
            Enter each team's points below and tap <kbd>+</kbd>. First to <strong>151</strong> wins.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bc-table-wrap">
      <div className={`bc-table cols-${cols}`} ref={ref}>
        <div className="bc-thead">
          <div className="bc-th bc-th-turn">#</div>
          <div className="bc-th" style={{ "--team": theme.teamA }}>{headers.a}</div>
          <div className="bc-th" style={{ "--team": theme.teamB }}>{headers.b}</div>
          {showThird && <div className="bc-th" style={{ "--team": theme.teamC }}>{headers.c}</div>}
          <div className="bc-th bc-th-act"></div>
        </div>
        <div className="bc-tbody">
          {rows.map((r, i) => {
            const milestone = showThird ? r.id % 3 === 0 : r.id % 4 === 0;
            const isLast = i === rows.length - 1;
            return (
              <div className={`bc-tr ${milestone ? "milestone" : ""} ${isLast ? "is-last" : ""}`} key={r.id}>
                <div className="bc-td bc-td-turn"><span className="bc-turn-pill">{r.turn}</span></div>
                <Cell value={r.a} delta={r.dA} mode={showDelta} />
                <Cell value={r.b} delta={r.dB} mode={showDelta} />
                {showThird && <Cell value={r.c} delta={r.dC} mode={showDelta} />}
                <div className="bc-td bc-td-act">
                  {isLast && (
                    <button className="bc-undo" onClick={onDeleteLast} title="Undo last round" aria-label="Undo last round">
                      <IconUndo />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Cell({ value, delta, mode }) {
  const tag = delta === 0 ? "BT" : `${delta > 0 ? "+" : ""}${delta}`;
  return (
    <div className="bc-td bc-td-num">
      <span className="bc-num">{value}</span>
      {mode === "chip" && (
        <span className={`bc-delta-chip ${delta === 0 ? "is-bt" : delta > 0 ? "is-pos" : "is-neg"}`}>{tag}</span>
      )}
      {mode === "inline" && (
        <span className="bc-delta-inline">({tag})</span>
      )}
    </div>
  );
}

/* ---------- input bar ---------- */
function InputBar({ draft, setDraft, headers, showThird, canAdd, onAdd, canSave, onSave }) {
  const refs = { a: useRef(null), b: useRef(null), c: useRef(null) };
  const onKey = (e, k) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const order = showThird ? ["a", "b", "c"] : ["a", "b"];
      const i = order.indexOf(k);
      if (i < order.length - 1) refs[order[i + 1]].current?.focus();
      else if (canAdd) onAdd();
    }
  };
  return (
    <div className="bc-input-bar">
      <div className="bc-inputs">
        <NumField label={headers.a} team="a" value={draft.a}
          onChange={v => setDraft({ ...draft, a: v })} ref={refs.a} onKeyDown={(e) => onKey(e, "a")} />
        <NumField label={headers.b} team="b" value={draft.b}
          onChange={v => setDraft({ ...draft, b: v })} ref={refs.b} onKeyDown={(e) => onKey(e, "b")} />
        {showThird && (
          <NumField label={headers.c} team="c" value={draft.c}
            onChange={v => setDraft({ ...draft, c: v })} ref={refs.c} onKeyDown={(e) => onKey(e, "c")} />
        )}
      </div>
      <div className="bc-input-actions">
        {canSave && (
          <button className="bc-btn bc-btn-ghost" onClick={onSave} title="Save game and start new" aria-label="Save game">
            <IconFlag /> <span>New</span>
          </button>
        )}
        <button
          className={`bc-btn bc-btn-primary ${canAdd ? "" : "is-disabled"}`}
          onClick={onAdd}
          disabled={!canAdd}
          aria-label="Add round"
        >
          <IconPlus /> <span>Add</span>
        </button>
      </div>
    </div>
  );
}

const NumField = React.forwardRef(function NumField({ label, team, value, onChange, onKeyDown }, ref) {
  return (
    <label className={`bc-field bc-field-${team}`}>
      <span className="bc-field-label" style={{ "--team": `var(--team-${team})` }}>{label}</span>
      <input
        ref={ref}
        type="number"
        inputMode="numeric"
        pattern="[0-9]*"
        placeholder="0"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={onKeyDown}
      />
    </label>
  );
});

/* ---------- modals ---------- */
function Modal({ title, children, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return (
    <div className="bc-modal-shade" onClick={onClose}>
      <div className="bc-modal" onClick={(e) => e.stopPropagation()}>
        <div className="bc-modal-head">
          <h2>{title}</h2>
          <button className="bc-icon-btn" onClick={onClose} aria-label="Close"><IconClose /></button>
        </div>
        <div className="bc-modal-body">{children}</div>
      </div>
    </div>
  );
}

function SettingsBody({ headers, setHeaders, showThird, setShowThird, onResetAll, t, setTweak }) {
  const themeOpts = [
    { value: "felt", label: "Felt", swatches: ["#0e2b22", "#b8242b", "#c79a3e"] },
    { value: "parchment", label: "Parchment", swatches: ["#efe7d2", "#9e1b22", "#a67524"] },
    { value: "midnight", label: "Midnight", swatches: ["#0b0f1a", "#e2545a", "#e7c46a"] },
  ];
  const densityOpts = [
    { value: "compact", label: "Compact" },
    { value: "comfortable", label: "Comfy" },
    { value: "roomy", label: "Roomy" },
  ];
  const deltaOpts = [
    { value: "chip", label: "Chip" },
    { value: "inline", label: "Inline" },
    { value: "off", label: "Off" },
  ];
  return (
    <div className="bc-settings">
      <section>
        <h3>Team names</h3>
        <p className="bc-help">Use commas for multiple players on one team — turn dealer hint cycles through all names.</p>
        <div className="bc-name-grid">
          <NameField label="Team 1" color="var(--team-a)" value={headers.a}
            onChange={(v) => setHeaders({ ...headers, a: v })} />
          <NameField label="Team 2" color="var(--team-b)" value={headers.b}
            onChange={(v) => setHeaders({ ...headers, b: v })} />
          {showThird && (
            <NameField label="Team 3" color="var(--team-c)" value={headers.c}
              onChange={(v) => setHeaders({ ...headers, c: v })} />
          )}
        </div>
      </section>

      <section>
        <h3>Players</h3>
        <div className="bc-toggle-row">
          <div>
            <div className="bc-toggle-title">Three-team mode</div>
            <div className="bc-help">For 3-handed Belot. Adds a third score column.</div>
          </div>
          <Switch checked={showThird} onChange={setShowThird} />
        </div>
      </section>

      <section>
        <h3>Theme</h3>
        <div className="bc-theme-grid">
          {themeOpts.map(opt => (
            <button
              key={opt.value}
              className={`bc-theme-card ${t.theme === opt.value ? "is-on" : ""}`}
              onClick={() => setTweak("theme", opt.value)}
            >
              <div className="bc-theme-preview">
                {opt.swatches.map((c, i) => (
                  <span key={i} style={{ background: c }} />
                ))}
              </div>
              <span className="bc-theme-name">{opt.label}</span>
            </button>
          ))}
        </div>
      </section>

      <section>
        <h3>Density</h3>
        <Segmented
          value={t.density}
          options={densityOpts}
          onChange={(v) => setTweak("density", v)}
        />
        <p className="bc-help">Controls row padding in the score table.</p>
      </section>

      <section>
        <h3>Round delta</h3>
        <Segmented
          value={t.showDelta}
          options={deltaOpts}
          onChange={(v) => setTweak("showDelta", v)}
        />
        <p className="bc-help">How the points-added per round are shown next to each total.</p>
      </section>

      <section>
        <h3>Behavior</h3>
        <div className="bc-toggle-row">
          <div>
            <div className="bc-toggle-title">Next-dealer hint</div>
            <div className="bc-help">Shows whose turn it is to deal under the totals.</div>
          </div>
          <Switch checked={t.showTurnDots} onChange={(v) => setTweak("showTurnDots", v)} />
        </div>
      </section>

      <section className="bc-danger">
        <h3>Danger zone</h3>
        <button className="bc-btn bc-btn-danger" onClick={onResetAll}>Reset everything</button>
      </section>
    </div>
  );
}

function Segmented({ value, options, onChange }) {
  return (
    <div className="bc-seg" role="radiogroup">
      {options.map(o => (
        <button
          key={o.value}
          className={`bc-seg-btn ${value === o.value ? "is-on" : ""}`}
          onClick={() => onChange(o.value)}
          role="radio"
          aria-checked={value === o.value}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function NameField({ label, color, value, onChange }) {
  return (
    <label className="bc-name-field">
      <span className="bc-name-dot" style={{ background: color }} />
      <span className="bc-name-label">{label}</span>
      <input type="text" value={value} onChange={(e) => onChange(e.target.value)} placeholder="Names..." />
    </label>
  );
}

function Switch({ checked, onChange }) {
  return (
    <button
      className={`bc-switch ${checked ? "on" : ""}`}
      onClick={() => onChange(!checked)}
      role="switch"
      aria-checked={checked}
    >
      <span />
    </button>
  );
}

function HistoryBody({ history, onClear }) {
  if (!history.length) {
    return (
      <div className="bc-history-empty">
        <div className="bc-history-empty-icon"><IconHistory /></div>
        <div className="bc-history-empty-title">No games yet</div>
        <div className="bc-help">Saved games appear here. Tap <strong>New</strong> after a finished game to archive it.</div>
      </div>
    );
  }
  return (
    <div className="bc-history">
      <div className="bc-history-list">
        {[...history].reverse().map((g) => {
          const teams = [
            { name: g.headers.a, v: g.totals.a },
            { name: g.headers.b, v: g.totals.b },
            ...(g.showThird ? [{ name: g.headers.c, v: g.totals.c }] : []),
          ];
          const winner = teams.reduce((a, b) => (b.v > a.v ? b : a), teams[0]);
          const d = new Date(g.date);
          return (
            <div className="bc-history-item" key={g.id}>
              <div className="bc-history-date">
                <span className="bc-history-day">{d.toLocaleDateString(undefined, { month: "short", day: "numeric" })}</span>
                <span className="bc-history-time">{d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}</span>
              </div>
              <div className="bc-history-scores">
                {teams.map((t, i) => (
                  <div className={`bc-history-team ${t.v === winner.v ? "is-win" : ""}`} key={i}>
                    <span className="bc-history-team-name">{t.name}</span>
                    <span className="bc-history-team-v">{t.v}</span>
                  </div>
                ))}
              </div>
              <div className="bc-history-meta">{g.rows.length} rounds</div>
            </div>
          );
        })}
      </div>
      <button className="bc-btn bc-btn-ghost" onClick={onClear}>Clear history</button>
    </div>
  );
}

function ConfirmDialog({ title, body, confirmLabel, onConfirm, onCancel, danger }) {
  return (
    <div className="bc-modal-shade" onClick={onCancel}>
      <div className="bc-confirm" onClick={(e) => e.stopPropagation()}>
        <h3>{title}</h3>
        <p>{body}</p>
        <div className="bc-confirm-actions">
          <button className="bc-btn bc-btn-ghost" onClick={onCancel}>Cancel</button>
          <button className={`bc-btn ${danger ? "bc-btn-danger" : "bc-btn-primary"}`} onClick={onConfirm}>{confirmLabel}</button>
        </div>
      </div>
    </div>
  );
}

/* ---------- atoms ---------- */
function IconBtn({ children, onClick, label }) {
  return (
    <button className="bc-icon-btn" onClick={onClick} aria-label={label} title={label}>
      {children}
    </button>
  );
}

function BelotMark({ theme, large }) {
  const size = large ? 56 : 32;
  return (
    <svg className="bc-mark" width={size} height={size} viewBox="0 0 40 40" aria-hidden="true">
      <defs>
        <linearGradient id="bcg" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={theme.accent2} stopOpacity="1" />
          <stop offset="1" stopColor={theme.accent2} stopOpacity="0.65" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="36" height="36" rx="9" fill={theme.ink} stroke="url(#bcg)" strokeWidth="1.4" />
      <path d="M20 30 C12 24 12 17 16 15 C18.5 13.7 20 15.5 20 17 C20 15.5 21.5 13.7 24 15 C28 17 28 24 20 30 Z"
        fill={theme.accent} />
    </svg>
  );
}

const IconCog = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" />
  </svg>
);
const IconHistory = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 12a9 9 0 1 0 3-6.7" /><path d="M3 4v5h5" /><path d="M12 7v5l3 2" />
  </svg>
);
const IconClose = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M6 6l12 12M18 6L6 18" />
  </svg>
);
const IconPlus = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
    <path d="M12 5v14M5 12h14" />
  </svg>
);
const IconUndo = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 14L4 9l5-5" /><path d="M4 9h11a5 5 0 0 1 0 10h-3" />
  </svg>
);
const IconFlag = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 21V4" /><path d="M4 4h12l-2 4 2 4H4" />
  </svg>
);

ReactDOM.createRoot(document.getElementById("root")).render(<BelotApp />);
